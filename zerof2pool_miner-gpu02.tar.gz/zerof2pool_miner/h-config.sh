#!/usr/bin/env bash

cd `dirname $0`

if [[ "$CUSTOM_URL" = "" ]];then
	echo "Mining pool address not filled in"
	exit 1
fi

conf=""
conf+="ADDRESS=\"$CUSTOM_TEMPLATE\""$'\n'
conf+="PROXY=\"$CUSTOM_URL\""$'\n'
conf+="PASS=\"$CUSTOM_PASS\""$'\n'
conf+="EXTRA=\"$CUSTOM_USER_CONFIG\""$'\n'

echo "$conf" > $CUSTOM_CONFIG_FILENAME
